package com.wedding.checkout.service;

import com.wedding.checkout.domain.Orders;
import com.wedding.checkout.domain.Payment;
import com.wedding.checkout.dto.*;
import com.wedding.checkout.repository.OrderRepository;
import com.wedding.checkout.repository.PaymentRepository;
import com.wedding.global.util.TossPaymentClient;
import com.wedding.global.dto.PageResponseDTO;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Log4j2
public class AdminOrderServiceImpl implements AdminOrderService {

    private final OrderRepository orderRepository;
    private final PaymentRepository paymentRepository;
    private final TossPaymentClient tossPaymentClient;
    private final OrderNotificationService orderNotificationService;

    @Override
    public PageResponseDTO<AdminOrderListDTO> listOrders(AdminOrderSearchDTO searchDTO) {

        Sort sort = "oldest".equals(searchDTO.getSortType())
                ? Sort.by("ono").ascending()
                : Sort.by("ono").descending();

        Pageable pageable = PageRequest.of(searchDTO.getPage() - 1, searchDTO.getSize(), sort);

        Page<Orders> result = orderRepository.adminSearchOrders(
                searchDTO.getKeyword(), searchDTO.getStatus(), pageable);

        List<AdminOrderListDTO> dtoList = result.get().map(o -> AdminOrderListDTO.builder()
                .ono(o.getOno())
                .orderNumber(o.getOrderNumber())
                .memberEmail(o.getMember().getEmail())
                .receiverName(o.getReceiverName())
                .totalPrice(o.getTotalPrice())
                .orderStatus(o.getOrderStatus())
                .regDate(o.getRegDate())
                .build()
        ).collect(Collectors.toList());

        return PageResponseDTO.<AdminOrderListDTO>withAll()
                .dtoList(dtoList)
                .pageRequestDTO(searchDTO)
                .totalCount(result.getTotalElements())
                .build();
    }

    @Override
    public AdminOrderDetailDTO getOrderDetail(Long ono) {

        Orders orders = orderRepository.findById(ono)
                .orElseThrow(() -> new NoSuchElementException("주문을 찾을 수 없습니다. ono=" + ono));

        Optional<Payment> paymentOpt = paymentRepository.findLatestByOrderOno(ono);

        List<OrderItemDTO> items = orders.getOrderItems().stream()
                .map(oi -> OrderItemDTO.builder()
                        .pno(oi.getProduct().getPno())
                        .pname(oi.getPnameSnapshot())
                        .price(oi.getPriceSnapshot())
                        .qty(oi.getQty())
                        .build())
                .collect(Collectors.toList());

        AdminOrderDetailDTO.AdminOrderDetailDTOBuilder builder = AdminOrderDetailDTO.builder()
                .ono(orders.getOno())
                .orderNumber(orders.getOrderNumber())
                .memberEmail(orders.getMember().getEmail())
                .receiverName(orders.getReceiverName())
                .receiverPhone(orders.getReceiverPhone())
                .zipcode(orders.getZipcode())
                .address(orders.getAddress())
                .addressDetail(orders.getAddressDetail())
                .request(orders.getRequest())
                .trackingNo(orders.getTrackingNo())
                .adminMemo(orders.getAdminMemo())
                .totalPrice(orders.getTotalPrice())
                .shippingFee(orders.getShippingFee())
                .orderStatus(orders.getOrderStatus())
                .regDate(orders.getRegDate())
                .items(items);

        paymentOpt.ifPresent(payment -> builder
                .payMethod(payment.getPayMethod())
                .pgProvider(payment.getPgProvider())
                .pgTid(payment.getPgTid())
                .payStatus(payment.getPayStatus())
                .approvedAt(payment.getApprovedAt())
        );

        return builder.build();
    }

    @Override
    public void changeStatus(Long ono, String newStatus) {

        Orders orders = orderRepository.findById(ono)
                .orElseThrow(() -> new NoSuchElementException("주문을 찾을 수 없습니다. ono=" + ono));

        orders.changeStatus(newStatus);
        orderRepository.save(orders);

        orderNotificationService.sendStatusChangeNotification(orders.getMember().getEmail(), orders, newStatus);
    }

    @Override
    public void bulkChangeStatus(List<Long> onos, String newStatus) {
        onos.forEach(ono -> changeStatus(ono, newStatus));
    }

    @Override
    public void updateShippingInfo(Long ono, String receiverName, String receiverPhone,
                                   String zipcode, String address, String addressDetail) {

        Orders orders = orderRepository.findById(ono)
                .orElseThrow(() -> new NoSuchElementException("주문을 찾을 수 없습니다. ono=" + ono));

        orders.changeShippingInfo(receiverName, receiverPhone, zipcode, address, addressDetail);
        orderRepository.save(orders);
    }

    @Override
    public void updateTrackingNo(Long ono, String trackingNo) {

        Orders orders = orderRepository.findById(ono)
                .orElseThrow(() -> new NoSuchElementException("주문을 찾을 수 없습니다. ono=" + ono));

        orders.changeTrackingNo(trackingNo);
        orderRepository.save(orders);
    }

    @Override
    public void updateAdminMemo(Long ono, String memo) {

        Orders orders = orderRepository.findById(ono)
                .orElseThrow(() -> new NoSuchElementException("주문을 찾을 수 없습니다. ono=" + ono));

        orders.changeAdminMemo(memo);
        orderRepository.save(orders);
    }

    @Override
    public void refund(Long ono, String reason) {

        Orders orders = orderRepository.findById(ono)
                .orElseThrow(() -> new NoSuchElementException("주문을 찾을 수 없습니다. ono=" + ono));

        Payment payment = paymentRepository.findLatestByOrderOno(ono)
                .orElseThrow(() -> new NoSuchElementException("결제 정보를 찾을 수 없습니다. ono=" + ono));

        tossPaymentClient.cancelPayment(payment.getPgTid(), reason);

        payment.changePayStatus("CANCELED");
        orders.changeStatus("REFUNDED");

        orderRepository.save(orders);

        orderNotificationService.sendStatusChangeNotification(orders.getMember().getEmail(), orders, "REFUNDED");
    }

}