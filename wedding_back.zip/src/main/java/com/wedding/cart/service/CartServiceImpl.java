//package com.wedding.cart.service;
//
//import java.util.*;
//
//import org.springframework.stereotype.Service;
//
//import com.wedding.cart.domain.CartOrder;
//import com.wedding.cart.domain.CartItem;
//import com.wedding.member.domain.Member;
//import com.wedding.product.domain.Product;
//import com.wedding.cart.dto.CartItemDTO;
//import com.wedding.cart.dto.CartItemListDTO;
//import com.wedding.cart.repository.CartItemRepository;
//import com.wedding.cart.repository.CartRepository;
//import lombok.RequiredArgsConstructor;
//import lombok.extern.log4j.Log4j2;
//
//@RequiredArgsConstructor
//@Service
//@Log4j2
//public class CartServiceImpl implements CartService {
//
//    private final CartRepository cartRepository;
//
//    private final CartItemRepository cartItemRepository;
//
//    @Override
//    public List<CartItemListDTO> addOrModify(CartItemDTO cartItemDTO) {
//
//        String email = cartItemDTO.getEmail();
//
//        Long pno = cartItemDTO.getPno();
//
//        int qty = cartItemDTO.getQty();
//
//        Long cino = cartItemDTO.getCino();
//
//        log.info("======================================================");
//        log.info(cartItemDTO.getCino() == null);
//
//        if(cino != null) { //장바구니 아이템 번호가 있어서 수량만 변경하는 경우
//
//            Optional<CartItem> cartItemResult = cartItemRepository.findById(cino);
//
//            CartItem cartItem = cartItemResult.orElseThrow();
//
//            cartItem.changeQty(qty);
//
//            cartItemRepository.save(cartItem);
//
//            return getCartItems(email);
//        }
//
//        //장바구니 아이템 번호 cino가 없는 경우
//
//        //사용자의 카트
//        CartOrder cart = getCart(email);
//
//        CartItem cartItem = null;
//
//        //이미 동일한 상품이 담긴적이 있을 수 있으므로
//        cartItem = cartItemRepository.getItemOfPno(email, pno);
//
//        if(cartItem == null){
//            Product product = Product.builder().pno(pno).build();
//            cartItem = CartItem.builder().product(product).cartOrder(cart).qty(qty).build();
//
//        }else {
//            cartItem.changeQty(qty);
//        }
//
//        //상품 아이템 저장
//        cartItemRepository.save(cartItem);
//
//        return getCartItems(email);
//    }
//
//
//    //사용자의 장바구니가 없었다면 새로운 장바구니를 생성하고 반환
//    private CartOrder getCart(String email ){
//
//        CartOrder cart = null;
//
//        Optional<CartOrder> result = cartRepository.getCartOfMember(email);
//
//        if(result.isEmpty()) {
//
//            log.info("Cart of the member is not exist!!");
//
//            Member member = Member.builder().email(email).build();
//
//            CartOrder tempCart = CartOrder.builder().member(member).build();
//
//            cart = cartRepository.save(tempCart);
//
//        }else {
//            cart = result.get();
//        }
//
//        return cart;
//
//    }
//
//    @Override
//    public List<CartItemListDTO> getCartItems(String email) {
//
//        return cartItemRepository.getItemsOfCartDTOByEmail(email);
//    }
//
//    @Override
//    public List<CartItemListDTO> remove(Long cino) {
//
//        Long cno  = cartItemRepository.getCartFromItem(cino);
//
//        log.info("cart no: " + cno);
//
//        cartItemRepository.deleteById(cino);
//
//        return cartItemRepository.getItemsOfCartDTOByCart(cno);
//    }
//}