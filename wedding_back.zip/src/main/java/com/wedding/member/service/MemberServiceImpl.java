package com.wedding.member.service;

import java.util.LinkedHashMap;
import java.util.Optional;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.wedding.global.advice.DuplicateEmailException;
import com.wedding.member.domain.Member;
import com.wedding.member.domain.MemberDetail;
import com.wedding.member.domain.MemberRole;
import com.wedding.member.domain.TermsAgree;
import com.wedding.member.dto.JoinDTO;
import com.wedding.member.dto.MemberDTO;
import com.wedding.member.dto.MemberModifyDTO;
import com.wedding.member.repository.MemberDetailRepository;
import com.wedding.member.repository.MemberRepository;
import com.wedding.member.repository.TermsAgreeRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Service
@RequiredArgsConstructor
@Log4j2
public class MemberServiceImpl implements MemberService {

  private final MemberRepository memberRepository;
  private final MemberDetailRepository memberDetailRepository;
  private final TermsAgreeRepository termsAgreeRepository;
    private final PasswordEncoder passwordEncoder;

  @Override
  public MemberDTO getKakaoMember(String accessToken) {

    String email = getEmailFromKakaoAccessToken(accessToken);

    log.info("email: " + email );

Optional<Member> result = memberRepository.findById(email);

    // 기존의 회원
    if(result.isPresent()){
      MemberDTO memberDTO = entityToDTO(result.get());

      return memberDTO;
    }

    // 회원이 아니었다면
    // 닉네임은 '소셜회원'으로
    // 패스워드는 임의로 생성
    Member socialMember = makeSocialMember(email);
    memberRepository.save(socialMember);

    MemberDTO memberDTO = entityToDTO(socialMember);

    return memberDTO;
  }

  private String getEmailFromKakaoAccessToken(String accessToken){

    String kakaoGetUserURL = "https://kapi.kakao.com/v2/user/me";

    if(accessToken == null){
      throw new RuntimeException("Access Token is null");
    }
    RestTemplate restTemplate = new RestTemplate();

    HttpHeaders headers = new HttpHeaders();
    headers.add("Authorization", "Bearer " + accessToken);
    headers.add("Content-Type","application/x-www-form-urlencoded");
    HttpEntity<String> entity = new HttpEntity<>(headers);

    UriComponents uriBuilder = UriComponentsBuilder.fromHttpUrl(kakaoGetUserURL).build();

    ResponseEntity<LinkedHashMap> response = 
      restTemplate.exchange(
      uriBuilder.toString(), 
      HttpMethod.GET, 
      entity, 
      LinkedHashMap.class);

    log.info(response);

    LinkedHashMap<String, LinkedHashMap> bodyMap = response.getBody();

    log.info("------------------------------");
    log.info(bodyMap);

    LinkedHashMap<String, String> kakaoAccount = bodyMap.get("kakao_account");

    log.info("kakaoAccount: " + kakaoAccount);

    return kakaoAccount.get("email");

  }

    private String makeTempPassword() {

    StringBuffer buffer = new StringBuffer();

    for(int i = 0;  i < 10; i++){
      buffer.append(  (char) ( (int)(Math.random()*55) + 65  ));
    }
    return buffer.toString();
  }

  
  private Member makeSocialMember(String email) {

   String tempPassword = makeTempPassword();

   log.info("tempPassword: " + tempPassword);

   String nickname = "소셜회원";

   Member member = Member.builder()
   .email(email)
   .pw(passwordEncoder.encode(tempPassword))
   .nickname(nickname)
   .social(true)
   .build();

   member.addRole(MemberRole.USER);

   return member;

  }

  
    @Override
  public void modifyMember(MemberModifyDTO memberModifyDTO) {

    Optional<Member> result = memberRepository.findById(memberModifyDTO.getEmail());

    Member member = result.orElseThrow();

    member.changePw(passwordEncoder.encode(memberModifyDTO.getPw()));
    member.changeSocial(false);
    member.changeNickname(memberModifyDTO.getNickname());

    memberRepository.save(member);

  }

  @Override
  public void join(JoinDTO joinDTO) {

    // 이메일 중복 체크
    if (memberRepository.findById(joinDTO.getEmail()).isPresent()) {
      throw new DuplicateEmailException("이미 가입된 이메일입니다.");
    }

    // 1. Member 저장
    Member member = Member.builder()
            .email(joinDTO.getEmail())
            .pw(passwordEncoder.encode(joinDTO.getPw()))
            .nickname(joinDTO.getNickname())
            .social(false)
            .build();

    member.addRole(MemberRole.USER);

    memberRepository.save(member);

    // 2. MemberDetail 저장
    MemberDetail memberDetail = MemberDetail.builder()
            .member(member)
            .name(joinDTO.getName())
            .phone(joinDTO.getPhone())
            .build();

    memberDetailRepository.save(memberDetail);

    // 3. TermsAgree 저장
    TermsAgree termsAgree = TermsAgree.builder()
            .member(member)
            .termsAgree(joinDTO.isTermsAgree())
            .privacyAgree(joinDTO.isPrivacyAgree())
            .marketing(joinDTO.isMarketing())
            .build();

    termsAgreeRepository.save(termsAgree);

    log.info("join success: " + joinDTO.getEmail());
  }
}